package com.example.services;

import java.util.ArrayList;
//import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Optional;
//import java.util.jar.Attributes;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.PartialResultException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.directory.Attributes;

import com.example.data.User;

public class AuthenticateUser {

    private static final String ACTIVE_DIRECTORY_USER_PATH = "DC=de,DC=...";


    public Optional<User> authenticateUser(User user)
    throws AuthenticationException{
        try{
            DirContext ctx = new InitialDirContext(getLdapVar(user));
            return Optional.of(user);

        }catch(NamingException e){
            throw new AuthenticationException("Benutzername oder Passwort falsch");
        }
    }

    public List<String> userIsInGrps(User user){
     try{
        DirContext ctx = new InitialDirContext(getLdapVar(user));
        String ldapPrefix = "";
        SearchControls ctls = new SearchControls();
        String[] attrIDs ={"cn", "memberOf"};
        ctls.setReturningAttributes(attrIDs);
        ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        
        NamingEnumeration<SearchResult> result = ctx.search(ACTIVE_DIRECTORY_USER_PATH,
        "(&(objectclass=user)(sAMAccountName=" + user.getName() + "))",
        ctls);
        List<String> groupList = new ArrayList<String>();
        try{
            while (result!= null && result.hasMore()) {
                SearchResult entry = result.next();
                Attributes attribute = entry.getAttributes();
                NamingEnumeration<?> memberList = attribute.get("memberOf").getAll();
                while (memberList != null &&memberList.hasMore()) {
                    String member = (String) memberList.next();
                    if (member.contains(ldapPrefix)) {
                        String[] splitArray = member.split(",");
                        String groupName = splitArray[0].substring(3);
                        groupList.add(groupName);
                    }
                }
            }
        }catch(PartialResultException prExc){

        }
        if (groupList != null && groupList.size() > 0) {
            return groupList;           
        }else{
            return null;
        }

       }catch(NamingException e){

       }
        return null;

    }

    public Hashtable<String,String> getLdapVar(User user) {
        Hashtable<String,String> env = new Hashtable<>();
        env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL,"ldap://ldap.example.de");
        env.put(Context.SECURITY_PRINCIPAL, user.getName());
        env.put(Context.SECURITY_CREDENTIALS, user.getPassword());
        return env;
    }

}
